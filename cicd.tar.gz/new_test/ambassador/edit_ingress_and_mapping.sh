#!/bin/bash

kubectl apply -f basic-ingress.yaml
kubectl apply -f mapping.yaml
kubectl apply -f hc.yaml

