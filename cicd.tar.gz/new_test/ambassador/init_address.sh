#!/bin/bash

gcloud compute address describe myclusteraddr --global

