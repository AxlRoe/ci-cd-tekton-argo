#!/bin/bash

kubectl apply -f web-deployment.yaml 
kubectl apply -f web-service.yaml 
kubectl apply -f basic-ingress.yaml 
