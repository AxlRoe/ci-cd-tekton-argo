## Guestbook application example

[![Open in Cloud Shell](https://gstatic.com/cloudssh/images/open-btn.svg)](https://ssh.cloud.google.com/cloudshell/editor?cloudshell_git_repo=https://github.com/GoogleCloudPlatform/kubernetes-engine-samples&cloudshell_tutorial=README.md&cloudshell_workspace=guestbook/)

This example shows how to build a simple, multi-tier web application using Kubernetes and [Docker](https://www.docker.com/).

Please follow the tutorial at https://cloud.google.com/kubernetes-engine/docs/tutorials/guestbook.
