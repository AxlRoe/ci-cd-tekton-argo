# Kubernetes Engine Quickstart

[![Open in Cloud Shell](https://gstatic.com/cloudssh/images/open-btn.svg)](https://ssh.cloud.google.com/cloudshell/editor?cloudshell_git_repo=https://github.com/GoogleCloudPlatform/kubernetes-engine-samples&cloudshell_tutorial=README.md&cloudshell_workspace=quickstart/)

Please follow the [Deploying a language-specific app][quickstart] quickstart to
run the code in this directory.

[quickstart]: https://cloud.google.com/kubernetes-engine/docs/quickstarts/deploying-a-language-specific-app

