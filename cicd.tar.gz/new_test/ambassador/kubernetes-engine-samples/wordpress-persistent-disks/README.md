# Using Persistent Disks with WordPress and MySQL

[![Open in Cloud Shell](https://gstatic.com/cloudssh/images/open-btn.svg)](https://ssh.cloud.google.com/cloudshell/editor?cloudshell_git_repo=https://github.com/GoogleCloudPlatform/kubernetes-engine-samples&cloudshell_tutorial=README.md&cloudshell_workspace=wordpress-persistent-disks/)

Follow this tutorial at https://cloud.google.com/kubernetes-engine/docs/tutorials/persistent-disk/


