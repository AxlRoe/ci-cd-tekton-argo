#!/bin/bash

kubectl create namespace argocd
kubectl apply -n argocd -f https://raw.githubusercontent.com/argoproj/argo-cd/v2.1.2/manifests/install.yaml
kubectl apply -f argocd-ambassador.yml
kubectl -n argocd patch secret argocd-secret \
  -p '{"stringData": {
    "admin.password": "$2a$10$rCcULJ2BXfPutS25bBcu2OTgC2BU.3oTO67bckf6YqCpUZZxpXGAu",
    "admin.passwordMtime": "'$(date +%FT%T%Z)'"
  }}'


echo "password now is KubernetesIsCool" 
