#!/bin/bash

IP=$(kubectl get svc ambassador -n ambassador -o "go-template={{range .status.loadBalancer.ingress}}{{or .ip .hostname}}{{end}}")
argocd login $IP --grpc-web-root-path /argo-cd
