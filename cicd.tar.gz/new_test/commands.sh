#!/bin/bash

gcloud container clusters create tektondemo-1 --zone europe-west2 --cluster-version 1.20 --machine-type n2-standard-2 \
                        --num-nodes=1 --preemptible --no-enable-autoupgrade \
                        --issue-client-certificate  \
                        --metadata disable-legacy-endpoints=true --local-ssd-count=1 \
                                --no-enable-cloud-logging --no-enable-cloud-monitoring \
                                --no-enable-ip-alias --no-enable-autoupgrade

#--disk-type=pd-ssd --disk-size=10GB \
gcloud iam service-accounts create kaniko --display-name kaniko
        gcloud projects add-iam-policy-binding tekton-test-321920 \
         --member serviceAccount:kaniko@tekton-test-321920.iam.gserviceaccount.com \
         --role roles/storage.admin 
        gcloud projects add-iam-policy-binding tekton-test-321920 \
         --member serviceAccount:kaniko@tekton-test-321920.iam.gserviceaccount.com \
         --role roles/artifactregistry.repoAdmin

gcloud iam service-accounts keys create ./secrets/kaniko-secret.json \
                --iam-account kaniko@tekton-test-321920.iam.gserviceaccount.com

kubectl create secret generic kaniko-secret --from-file=./secrets/kaniko-secret.json 

#kubectl apply --filename https://storage.googleapis.com/tekton-releases/pipeline/latest/release.yaml
#kubectl apply -f skaffold-git.yaml
#kubectl apply -f skaffold-image-leeroy-web.yaml
#kubectl apply -f build-docker-image-from-git-source.yaml
#kubectl apply -f build-docker-image-from-git-source-task-run.yaml
##tkn taskrun logs build-docker-image-from-git-source-task-run
#
##gcloud container clusters delete tektondemo-1 --zone europe-west2
##gcloud projects remove-iam-policy-binding tekton-test-321920 \
##         --member serviceAccount:kaniko@tekton-test-321920.iam.gserviceaccount.com \
##         --role roles/storage.admin
##gcloud projects remove-iam-policy-binding tekton-test-321920 \
##         --member serviceAccount:kaniko@tekton-test-321920.iam.gserviceaccount.com \
##         --role roles/artifactregistry.repoAdmin
##gcloud -q iam service-accounts delete kaniko@tekton-test-321920.iam.gserviceaccount.com
##rm -rf secrets
##

