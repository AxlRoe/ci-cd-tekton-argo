#!/bin/bash

gcloud artifacts docker images delete europe-west2-docker.pkg.dev/tekton-test-321920/tekton-test-repo/app-test 

