#!/bin/bash

argocd app create 2048-game-app --repo https://github.com/AxlRoe/app-test --path . --dest-server https://kubernetes.default.svc --dest-namespace game-2048 --sync-option CreateNamespace=true
