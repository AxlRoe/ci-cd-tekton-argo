#!/bin/bash

export SCM_USERNAME=AxlRoe
export SCM_PAT=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 
#argocd repo add https://github.com/AxlRoe/tekton-test --username $SCM_USERNAME --password $SCM_PAT
argocd repo add https://github.com/AxlRoe/app-test --username $SCM_USERNAME --password $SCM_PAT
